export const TEXT_DOMAIN = "cwp-gutenberg-forms"; // text-domain



//? some endpoints
export const LIBRARY_PROXY = "https://raw.githubusercontent.com/ZafarKamal123/gutenberg-forms-templates/master/library.json";
export const DATA_PROXY = "https://raw.githubusercontent.com/ZafarKamal123/gutenberg-forms-templates/master/data.json";