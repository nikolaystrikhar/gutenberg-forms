import React from "react";

function Toolbar() {
	return <h1>Hola</h1>;
}

export default Toolbar;
