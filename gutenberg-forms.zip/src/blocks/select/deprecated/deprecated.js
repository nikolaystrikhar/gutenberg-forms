import { attributes } from "../block.json";

// deprecated version
import edit from "./edit";
import save from "./save";

export const deprecated = [
	{
		attributes,
		edit,
		save,
	},
];
