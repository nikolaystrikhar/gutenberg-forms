/**
 * ! Handling the deprecation
 */

import { attributes } from "../block.json";
import edit from "./edit";
import save from "./save";

export const deprecated = [
	{
		attributes,
		edit,
		save,
	},
];
