import React from "react";
import ProgressBar from "./components/progressBar";

function save(props) {
	return <ProgressBar {...props} />;
}

export default save;
