import blockData from "./block.json";

export const deprecated = [
	{
		attributes: {
			...blockData.attributes,
		},
	},
];
