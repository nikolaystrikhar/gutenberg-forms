<?php
/**
 * Plugin Name: gutenberg-forms
 * Plugin URI: https://github.com/ahmadawais/create-guten-block/
 * Description: gutenberg-forms — is a Gutenberg plugin.
 * Author: zafarKamal
 * Author URI: https://demo.cakewp.com/
 * Version: 1.0.0
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 *
 * @package CGB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once plugin_dir_path( __FILE__ ) . 'src/init.php';
