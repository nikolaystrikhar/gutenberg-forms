import { templateHandler } from './template-inserted'
import { softErrorHandler } from './softerror-encountered'

templateHandler.register()
softErrorHandler.register()
